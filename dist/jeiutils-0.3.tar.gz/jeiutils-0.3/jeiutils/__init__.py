class Achha:
    def __init__(self):
        print("Constructor ban gaya")

    def achhafunc(self, number):
        print("This is a function")
        return number
