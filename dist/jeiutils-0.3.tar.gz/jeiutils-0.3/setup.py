
from setuptools import setup
setup(name="jeiutils",
version="0.3",
description="This is code with harry package",
long_description = "This is a very very long description",
author="sergio",
packages=['jeiutils'],
install_requires=[])